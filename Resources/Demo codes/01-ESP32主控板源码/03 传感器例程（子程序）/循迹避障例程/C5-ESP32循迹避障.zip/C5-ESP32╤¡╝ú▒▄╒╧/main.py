import factory.z_main as ZL

# 程序入口
if __name__ == '__main__':
    ZL.z_main()